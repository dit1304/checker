# Bot Configuration
BOT_TOKEN = '8195505675:AAEb5lUIh8Pf46_g8XQT_C3yUlKYGg3AT1E'  # Replace with your actual bot token
BOT_USERNAME = 'zeroCC'  # Replace with your bot's username

# API Keys and Tokens
GOOGLE_API_KEY = "AIzaSyADbwRHdEK-J5sqgtvaVv4Kz_H9ymax7KE"
SEARCH_ENGINE_ID = "96750e7f8dfab47e1"
IPINFO_TOKEN = "4dd04ebcd1b3c1"



